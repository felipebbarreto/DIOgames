# jogospython

Description. 
The package jogospython is used to:
	- Import games from Brazil in your code
	- jogos
		- adivinhacao
		- jokenpo
		- parouimpar
		- jogodedados
		- megasena

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install jogospybr
```

## Author
felipeb_barreto

## License
[MIT](https://choosealicense.com/licenses/mit/)